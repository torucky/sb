plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.example.wordalert"; compileSdk = 35
    defaultConfig { applicationId = "com.example.wordalert"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.work:work-runtime-ktx:2.11.2")
}
